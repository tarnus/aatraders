SINC32 version 1.0.1
Copyright (c) 2000 Sean Campbell <whytwolf@spots.ab.ca>

0.9 Notes
<baracha@users.sourceforge.net>
Since I have no news from Sean, I released a working copy of Sinc32 rel.1.0.1.
This version has some bug fixes and some new feature. Now it is possible to
add command line parameters to scheduled jobs, blank lines in sinctab file
are ignored and an icon appears on the task bar when sinc32 runs. When scheduled
applications run, a different icon is displayed, to indicate that sinc32 has
pending jobs.

Visit http://sourceforge.net/projects/sinc/ to download the original version 1.0 
from the CVS repository.

1.0 About SINC32

SINC32 is the scheduling engine behind the Sinc utility.  Sinc is a cron-like 
scheduler for windows.  SINC32 reads a sinctab file (similar to a crontab) and
executes any pending jobs.

1.1 SINC32.zip Contents

SINC32 is distributed with the following files:

        - README.txt - this readme file
        - SINC32.exe - the executable application
        - copying.txt - the GNU GPL which SINC32 is distributed under
		- sinctab.stf - an example sinctab file
		- test.bat - a batch file to be used as test job

If any of these files are missing from your distribution, please contact:

        whytwolf@spots.ab.ca

This program is licensed under the GNU GPL and is free to distribute, use and modify.


2.0 SINC32 Setup

Place the SINC32 executable in any directory you wish.  Place the test.bat file in
the same directory if you're going to be running the included sinctab file.  The
default location for the sinctab file is in the same path of the exe, but that can
be changed by invoking SINC32 with the -f switch and specifying a full path to the 
sinctab location.

3.0 Sinctab

Sinctabs are similar to crontabs but contain some differences. SINC32 will match
a * in a sinctab to any available time, and it can read a comment line indicated
by a line starting with the '#' character and is able to recognize a blank line.
All jobs to be run must be listed after the five time-placeholder as a command 
line with optional command line parameters on the same line. In addition you can
prefix each entry with the plus sign (+), indicating that this job will be executed 
just once.
At the moment Sinc can only run existing executable files, that is it can't
run entry such as dir *.tmp > tmp_list.txt (dos shell commands).
In this case you must create a batch file with all the command you need, and add an
entry in the sinctab file, pointing to this file. Moreover comma separated
entries (such as * * * * 1,3,5) are not supported. You have to add a line for each
entry.
Finally Sinc32 reads the sinctab file each time, so that you can edit it without
stopping the program. If you think this feature is time consuming (or other) and
you prefer to have sinc read sinctab just once, write an e-mail to authors.

From left to right the time fields are:

- minute
- hour
- day of month
- year
- day of week

Each must contain a integer number or a * indicating any value

The example sinctab is as follows:

# this is an example sinctab file
* * * * * test.bat
02 4 * * * test.bat
22 4 * * 0 test.bat
42 4 1 * * test.bat

3.1 User Interface
You can run sinc32.exe by dbl clicking the exe from the Explorer 
(then using the default sinctab.stf file) or by the dos prompt
(in this way you can pass -f <fullpath_filename> to use other
sinctab files and/or pass a -d parameter to create a console 
for verbose output/debug purpose).
To stop the program use the right click pop-up menu on the icon on the 
tray bar.
Someone should prefer to add an entry to the win registry to
launch Sinc32 at start-up:
[HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Run]
"Sinc32"="<disk>:\\<Sinc32_path>\\sinc32.exe <cmd params such as -f>"

4.0 Credits

Sean Campbell	- Preliminary design and development of version 0.9
Tyrell Kumlin	- Development assistance with version 0.9
Talucci Andrea	- Port of SINC32 from console to Win32
				- primary coding of version 1.0

5.0 SINC32 Licensing

This program is free software; you can redistribute it and/or 
modify it under the terms of the GNU General Public License 
as published by the Free Software Foundation; either version 2 
of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
GNU General Public License for more details. 

You should have received a copy of the GNU General Public License 
along with this program; if not, write to the Free Software 
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 
